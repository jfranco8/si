#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from app import app
from flask import render_template, request, url_for, redirect, session, Flask, make_response
import json
import os
import sys
from hashlib import md5
import random
from os.path import isdir
import time
from app import database

@app.route('/')
@app.route('/index')
def index():
    print(url_for('static', filename='styles.css'))
    movies = database.todas()
    titulo = "Todas las muuuvies"
    return render_template('index.html', title = titulo, movies=movies)

#tipos de pelis
@app.route('/novedades')
def novedades():
    print(url_for('static', filename='styles.css'))
    movies = database.novedades()
    titulo = "Novedades"
    return render_template('index.html', title = titulo, movies=movies)


@app.route('/masvistas')
def masvistas():
    print(url_for('static', filename='styles.css'))
    movies = database.topventas()
    titulo = "Muuuvies mas vistas"
    return render_template('index.html', title = titulo, movies=movies)

#categorias de pelis
@app.route('/categorias/<cat>')
def categorias(cat):
    print(url_for('static', filename='styles.css'))
    catalogue_data = open(os.path.join(app.root_path,'catalogue/catalogue.json'), encoding="utf-8").read()
    catalogue = json.loads(catalogue_data)
    pelis = []
    if cat=="animacion":
        titulo="Animación"
    elif cat=="aventura":
        titulo="Aventura"
    elif cat=="comedia":
        titulo="Comedia"
    elif cat=="drama":
        titulo="Drama"
    elif cat=="miedo":
        titulo="Miedo"
    elif cat=="musical":
        titulo="Musical"
    elif cat=="romantica":
        titulo="Romántica"
    else:
        titulo="Ciencia ficcion"
    for p in catalogue['peliculas']:
        for c in p['categorias']:
            if c['cat'] == titulo:
                pelis.append(p)
    return render_template('index.html', title = titulo, movies=pelis)

#peli concreta
@app.route('/pelicula/<valor>/', methods=['GET', 'POST'])
def pelicula(valor):
    print(url_for('static', filename='styles.css'))
    peli = database.getmovie(valor)[0]
    categorias = database.getgenres(valor)
    actores = database.getactors(valor)
    directores = database.getdirectors(valor)
    producto = database.getproduct(valor)[0]

    if 'usuario' not in session:
        if request.method == 'POST':
            if not 'carrito' in session:
                session['carrito'] = []
            session['carrito'].append(producto)

    else:
        if request.method == 'POST':
            user = session['usuario']
            usuarios = database.getuser(user)
            id_usuario=usuarios[0]['customerid']
            # INSERT A ORDERDETAIL PARA ORDER CON STATUS NULL
            # database.getCurrentOrder()
            # database.inserIntoCarrito(str(id_usuario), str(producto['prod_id']))
            database.insertIntoOrders(producto['price'], str(id_usuario), producto['prod_id'])

    return render_template('pelicula.html', peli = peli, categorias = categorias, directores = directores, actores = actores, producto = producto)

#busqueda de peli
@app.route('/busqueda', methods=['GET', 'POST'])
def busqueda():
    print(url_for('static', filename='styles.css'))
    catalogue_data = open(os.path.join(app.root_path,'catalogue/catalogue.json')).read()
    catalogue = json.loads(catalogue_data)
    pelis = []
    if 'busqueda' in request.form:
        for p in catalogue['peliculas']:
            if request.form['busqueda'].lower() in p['titulo'].lower():
                pelis.append(p)
        return render_template('index.html', title = request.form['busqueda'], movies=pelis)
    else:
        return redirect(url_for('index'))


@app.route('/ayuda')
def ayuda():
    return render_template('ayuda.html')


@app.route('/cambiar_contrasena/<usuario>/', methods=['GET', 'POST'])
def cambiar_contrasena(usuario):
    path = os.path.dirname(__file__)
    path += "/usuarios/"+usuario+"/"
    datos = json.load(open(path+"datos.json"))
    passw=datos['psw']

    if request.method == 'POST':
        old_contr = request.form['old']
        new_contr1 = request.form['new1']
        new_contr2 = request.form['new2']

        if md5(old_contr.encode()).hexdigest() != passw:
            return render_template('cambiar_contrasena.html', title = "Cambiar contrasena", mal=True)

        datos = json.load(open(path+"datos.json"))
        datos['psw'] = md5(new_contr1.encode()).hexdigest()

        with open(path+"datos.json", 'w') as f:
            f.write(json.dumps(datos))

        return redirect(url_for('index'))
    return render_template('cambiar_contrasena.html', title = "Cambiar contrasena", mal=False)


@app.route('/perfil/<usuario>/', methods=['GET', 'POST'])
def perfil(usuario):
    path = os.path.dirname(__file__)
    path += "/usuarios/"+usuario+"/"
    datos = json.load(open(path+"datos.json"))
    username=datos['username'] #nombre de usuario
    passw=datos['psw'] #ps
    name=datos['nombre'] #nombre
    mail=datos['mail'] #mail
    card=datos['tarjeta'] #tarjeta
    cvc=datos['cvc'] #cvc
    saldo=datos['saldo'] #saldo
    error = False

    if request.method == 'POST':
        saldo_new = request.form['saldo_nuevo']
        if float(saldo_new) < 0:
            error = True
        else:
            saldo = float(saldo) + float(saldo_new)
        datos = json.load(open(path+"datos.json"))
        datos['saldo']=saldo
        with open(path+"datos.json", 'w') as f:
            f.write(json.dumps(datos))
    return render_template('perfil.html', name=name, passw=passw, username=username,
        mail=mail, card=card, saldo=saldo, error=error)


@app.route('/historial',methods=['GET', 'POST'])
def historial():
    path = os.path.dirname(__file__)
    path += "/usuarios/"+session['usuario']
    historial = json.load(open(path+"/historial.json"))['pedidos']
    datos = json.load(open(path+"/datos.json"))
    historial.reverse()
    return render_template('historial.html', title = "Historial", pedidos=historial, datos=datos)


@app.route('/carrito', methods=['GET', 'POST'])
def carrito():

    no_saldo = False
    no_registrado = False
    compra = False

    if not 'carrito' in session:
        session['carrito'] = []


    if request.method == 'POST':

        if 'usuario' in session:

            user = session['usuario']
            usuarios = database.getuser(user)

            # path = os.path.dirname(__file__)
            # path += "/usuarios/"+session['usuario']+"/"
            # datos = json.load(open(path+"datos.json"))
            # saldo=datos['saldo']
            saldo = database.getUserSaldo(session['usuario'])
            saldo = str(saldo)[2:-3]
            coste = database.getOrderPrice(usuarios[0]['customerid'])
            coste = str(coste)[11:-5]

            print('saldoooooo', saldo)
            print('costeeeeee', coste)

            if float(coste) <= float(saldo):
                saldo = float(saldo) - float(coste)
                # setOrderStatus(Paid)
                # Decrementar la cantidad del usuario
                database.setOrderStatusPaid(str(usuarios[0]['customerid']))
                database.setUserSaldo(str(usuarios[0]['customerid']), saldo)
                compra = True

            else:
                no_saldo = True


                # iculas_nombre = database.getPeliculasInCarrito()
                # no_registrado = True
                # print("AQUIIIII", peliculas_nombre)
                # return render_template('carrito.html', title = "Carrito", peliculas=peliculas_nombre,compra=compra, no_saldo=no_saldo, no_registrado=no_registrado)
            all_carrito = database.getPeliculasInCarrito(str(usuarios[0]['customerid']))
            return render_template('carrito.html', title = "Carrito", peliculas=all_carrito,compra=compra, no_saldo=no_saldo, no_registrado=no_registrado)


        else:
            # No registrado
            peliculas_nombre = []
            for prod in session['carrito']:
                peliculas_nombre.append(database.getPeliculasProdById(prod['movieid'])[0])
            no_registrado = True
            return render_template('carrito.html', title = "Carrito", peliculas=peliculas_nombre,compra=compra, no_saldo=no_saldo, no_registrado=no_registrado)

    else:

        if 'usuario' in session:

            user = session['usuario']
            usuarios = database.getuser(user)

            if session['carrito'] == []:
                for prod in session['carrito']:
                    pelicula = database.getPeliculasProdById(prod['movieid'])[0]
                    database.inserIntoCarrito( str(usuarios[0]['customerid']), str(pelicula['prod_id']))
                session['carrito'] = []
            all_carrito = database.getPeliculasInCarrito(str(usuarios[0]['customerid']))
            return render_template('carrito.html', title = "Carrito", peliculas=all_carrito,compra=compra, no_saldo=no_saldo, no_registrado=no_registrado)

        else:
            peliculas_nombre = []
            for prod in session['carrito']:
                peliculas_nombre.append(database.getPeliculasProdById(prod['movieid'])[0])
            return render_template('carrito.html', title = "Carrito", peliculas=peliculas_nombre,compra=compra, no_saldo=no_saldo, no_registrado=no_registrado)


    return render_template('carrito.html', title = "Carrito", peliculas=session['carrito'],compra=compra, no_saldo=no_saldo, no_registrado=no_registrado)


@app.route('/carrito/borrar/<valor>')
def carrito_borrar(valor):

    user = session['usuario']
    usuarios = database.getuser(user)
    id_usuario=usuarios[0]['customerid']

    database.borrarProductoCarrito(valor, id_usuario)

    return redirect(url_for('carrito'))


@app.route('/login', methods=['GET', 'POST'])
def login():
    # doc sobre request object en http://flask.pocoo.org/docs/1.0/api/#incoming-request-data
    if 'username' in request.form:
        if request.method == 'POST':
            user = request.form['username']
            resp = make_response(redirect(url_for('index')))
            resp.set_cookie('userID', user)

        if not database.isuser(user):
            return render_template('login_registro.html', title = "Log In", existe=True)
        else:
            usuarios = database.getuser(user)
            mail_usuario=usuarios[0]['email']
            passw_cif=usuarios[0]['password']
            passw = md5(request.form['password'].encode()).hexdigest()
            # aqui se deberia validar con fichero .dat del usuario
            cond = request.form['username'] == mail_usuario and passw_cif == passw
            if cond:
                session['usuario'] = request.form['username']
                session.modified = True
                if not 'carrito' in session:
                    session['carrito'] = []
                # se puede usar request.referrer para volver a la pagina desde la que se hizo login

                return resp
            else:
                # aqui se le puede pasar como argumento un mensaje de login invalido

                return render_template('login_registro.html', title = "Log In", existe=False)
    else:
        # se puede guardar la pagina desde la que se invoca
        session['url_origen']=request.referrer
        session.modified=True
        # print a error.log de Apache si se ejecuta bajo mod_wsgi
        print (request.referrer)
        return render_template('login_registro.html', title = "Log In", existe=False)

@app.route('/registro', methods=['GET', 'POST'])
def signup():
    if 'username' in request.form:
        if request.form['password']  == request.form['password2']:

            if request.method == 'POST':
                user = request.form['username']
                resp = make_response(redirect(url_for('index')))
                resp.set_cookie('userID', user)

                password_cif = md5(request.form['password'].encode()).hexdigest()
                nombre = request.form['nombre'],
                mail = request.form['mail'],
                tarjeta = request.form['tarjeta'],
                cvc = request.form['cvc'],
                saldo = random.randrange(100)
                id_cust_n = str(database.getMaxIdCustomer()[0])
                id_cust_n = id_cust_n[1:-2]
                id_cust = int(id_cust_n) + 1

                num_user_username = str(database.getNumberUsersWithUsername(user)[0])
                num_user_username = num_user_username[1:-2]
                num_user_username = int(num_user_username)
                if num_user_username != 0:
                    return render_template('registro.html', title = "Sign", existe=True)

                database.adduser(id_cust, user, password_cif, nombre, mail, tarjeta, cvc, saldo);

                session['usuario'] = request.form['mail']
                session.modified = True

                # historial.close()
                return resp
            else:
                return render_template('registro.html', title = "Sign", existe=True)
        else:
            return render_template('registro.html', title = "Sign", existe=False)
    return render_template('registro.html', title = "Sign", existe=False)


@app.route('/logout', methods=['GET', 'POST'])
def logout():
    session.pop('usuario', None)
    session['carrito'] = []
    # session.pop('carrito', None)
    return redirect(url_for('index'))
